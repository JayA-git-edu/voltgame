﻿const KEY = "volt-save";


export function loadSave() {
  const data = localStorage.getItem(KEY);
  return data ? JSON.parse(data) : {};
}


export function saveGame(data) {
  localStorage.setItem(KEY, JSON.stringify(data));
}