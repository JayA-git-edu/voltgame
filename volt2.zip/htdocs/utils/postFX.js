﻿let t = 0;


export function applyPostFX(ctx, canvas) {
  t += 0.02;


  // SCREEN PULSE
  ctx.fillStyle = `rgba(0,255,255,${0.03 + Math.sin(t)*0.01})`;
  ctx.fillRect(0, 0, canvas.width, canvas.height);


  // SCANLINES
  ctx.fillStyle = "rgba(0,0,0,0.15)";
  for (let y = 0; y < canvas.height; y += 4) {
    ctx.fillRect(0, y, canvas.width, 1);
  }
}