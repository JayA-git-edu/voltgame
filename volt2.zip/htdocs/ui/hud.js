﻿export function drawHUD(ctx, player) {
  ctx.fillStyle = "#0ff";
  ctx.fillRect(20, 20, 100, 10);
}