﻿export function showDialogue(lines) {
  let i = 0;
  const box = document.getElementById("dialogue");


  function next() {
    box.textContent = lines[i++];
    if (i < lines.length) setTimeout(next, 1800);
  }
  next();
}