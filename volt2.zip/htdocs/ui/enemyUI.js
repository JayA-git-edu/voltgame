﻿export function drawEnemyUI(ctx, enemy, cam) {
  ctx.strokeStyle = `hsl(${120 - enemy.alert * 120},100%,50%)`;
  ctx.beginPath();
  ctx.arc(enemy.x - cam.x, enemy.y - cam.y - 10, 10, 0, Math.PI * 2);
  ctx.stroke();
}