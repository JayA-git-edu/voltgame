﻿import { Input } from "../engine/input.js";
import { applyGravity } from "../engine/physics.js";

export class Player {
  constructor() {
    this.x = 100;
    this.y = 200;
    this.w = 40;
    this.h = 40;
    this.vx = 0;
    this.vy = 0;
    this.color = "cyan";
    this.glow = true;
    this.onGround = false;
  }

  update() {
    if (Input.keys["a"]) this.vx = -5;
    else if (Input.keys["d"]) this.vx = 5;
    else this.vx *= 0.8;

    if (Input.keys[" "] && this.onGround) this.vy = -12;

    applyGravity(this, 0.7);

    this.x += this.vx;
    this.y += this.vy;
  }
}
