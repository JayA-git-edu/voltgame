// VISUAL DEBUG FLAG
document.body.style.background = "red";

// BIG TEXT TEST
const msg = document.createElement("div");
msg.innerText = "JS IS RUNNING";
msg.style.position = "fixed";
msg.style.top = "40%";
msg.style.left = "50%";
msg.style.transform = "translate(-50%, -50%)";
msg.style.color = "white";
msg.style.fontSize = "48px";
msg.style.fontFamily = "monospace";
msg.style.zIndex = "9999";

document.body.appendChild(msg);

// CANVAS TEST
const canvas = document.getElementById("game");
if (canvas) {
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "lime";
  ctx.fillRect(50, 50, 200, 200);
}
