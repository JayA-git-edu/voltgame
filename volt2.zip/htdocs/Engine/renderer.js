﻿import { Camera } from "./camera.js";

export const Renderer = {
  ctx: null,

  init(canvas) {
    this.ctx = canvas.getContext("2d");
  },

  begin() {
this.ctx.fillStyle = "red";
this.ctx.fillRect(10, 10, 10, 10);

  },

  drawEntity(e) {
    const depth = 1 - e.y / 800;
    const scale = 1 + depth * 0.1;

    this.ctx.save();
    this.ctx.translate(e.x - Camera.x, e.y - Camera.y);
    this.ctx.scale(scale, scale);

    if (e.glow) {
      this.ctx.shadowBlur = 20;
      this.ctx.shadowColor = e.color;
    }

    this.ctx.fillStyle = e.color;
    this.ctx.fillRect(0, 0, e.w, e.h);
    this.ctx.restore();
  },

  drawPlatform(p) {
    this.ctx.fillStyle = "#033";
    this.ctx.fillRect(
      p.x - Camera.x,
      p.y - Camera.y + 6,
      p.w,
      p.h
    );

    this.ctx.fillStyle = "#0ff";
    this.ctx.fillRect(
      p.x - Camera.x,
      p.y - Camera.y,
      p.w,
      p.h
    );
  }
};
