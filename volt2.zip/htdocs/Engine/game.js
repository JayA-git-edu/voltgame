// ===== VISUAL PROOF THAT JS IS RUNNING =====
document.body.style.background = "#200";

const label = document.createElement("div");
label.innerText = "GAME.JS IS RUNNING";
label.style.position = "fixed";
label.style.top = "10px";
label.style.left = "10px";
label.style.color = "lime";
label.style.fontFamily = "monospace";
label.style.fontSize = "20px";
document.body.appendChild(label);

// ===== BASIC GAME SETUP =====
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

// Player
const player = {
  x: 100,
  y: 300,
  w: 40,
  h: 40,
  vx: 0,
  vy: 0,
  onGround: false
};

// Platform
const ground = {
  x: 0,
  y: 420,
  w: 900,
  h: 80
};

// Input
const keys = {};
window.addEventListener("keydown", e => keys[e.key] = true);
window.addEventListener("keyup", e => keys[e.key] = false);

// ===== GAME LOOP =====
function loop() {
  // Physics
  player.vy += 0.7;
  player.x += player.vx;
  player.y += player.vy;

  // Input
  if (keys["a"]) player.vx = -5;
  else if (keys["d"]) player.vx = 5;
  else player.vx *= 0.8;

  if (keys[" "] && player.onGround) {
    player.vy = -12;
    player.onGround = false;
  }

  // Collision
  if (
    player.y + player.h > ground.y &&
    player.x + player.w > ground.x &&
    player.x < ground.x + ground.w
  ) {
    player.y = ground.y - player.h;
    player.vy = 0;
    player.onGround = true;
  }

  // Draw
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Ground
  ctx.fillStyle = "#044";
  ctx.fillRect(ground.x, ground.y, ground.w, ground.h);

  // Player
  ctx.fillStyle = "cyan";
  ctx.shadowBlur = 20;
  ctx.shadowColor = "cyan";
  ctx.fillRect(player.x, player.y, player.w, player.h);
  ctx.shadowBlur = 0;

  requestAnimationFrame(loop);
}

loop();
