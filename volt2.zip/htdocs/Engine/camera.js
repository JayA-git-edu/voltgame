export const Camera = {
  x: 0,
  y: 0,

  update(target) {
    const targetX = target.x - 400;
    const targetY = target.y - 250;

    this.x += (targetX - this.x) * 0.1;
    this.y += (targetY - this.y) * 0.1;

    // 🔒 Clamp camera so it never goes negative
    this.x = Math.max(0, this.x);
    this.y = Math.max(0, this.y);
  }
};
