﻿export class NPC {
  constructor(x, y, dialogueId) {
    this.x = x;
    this.y = y;
    this.w = 30;
    this.h = 40;
    this.dialogueId = dialogueId;
    this.color = "#ff0";
  }
}