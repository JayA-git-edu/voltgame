﻿export class Boss {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.w = 100;
    this.h = 100;
    this.hp = 1000;
    this.color = "magenta";
    this.glow = true;
  }


  update() {}
}