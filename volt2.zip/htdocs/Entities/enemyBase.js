﻿export class Enemy {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.w = 32;
    this.h = 32;
    this.hp = 100;
    this.alert = 0;
    this.color = "#f55";
  }


  update() {}
}