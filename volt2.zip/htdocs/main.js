﻿import { Game } from "./engine/game.js";
import { Input } from "./engine/input.js";
import { Camera } from "./engine/camera.js";
import { Renderer } from "./engine/renderer.js";
import { resolvePlatforms } from "./engine/physics.js";
import { Player } from "./entities/player.js";
import { VoltageLeech } from "./world/world1_spark_city/enemies.js";
import { World1Levels } from "./world/world1_spark_city/levels.js";

const canvas = document.getElementById("game");
Renderer.init(canvas);
Input.init();

const player = new Player();
Game.entities.push(player);

const enemies = [
  new VoltageLeech(500, 380),
  new VoltageLeech(650, 380)
];
Game.entities.push(...enemies);

const platforms = World1Levels.platforms;

function loop(time) {
  Game.update(time);

  resolvePlatforms(player, platforms);
  Camera.update(player);

  Renderer.begin();

  platforms.forEach(p => Renderer.drawPlatform(p));
  Game.entities.forEach(e => Renderer.drawEntity(e));

  requestAnimationFrame(loop);
}

loop(0);
