﻿import { Enemy } from "../../entities/enemyBase.js";


export class VoltageLeech extends Enemy {
  constructor(x, y) {
    super(x, y);
    this.color = "cyan";
  }


  update() {
    this.alert += 0.02;
  }
}