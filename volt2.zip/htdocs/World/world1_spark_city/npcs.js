﻿import { NPC } from "../../entities/npcBase.js";


export const World1NPCs = [
  new NPC(200, 380, "intro_engineer")
];