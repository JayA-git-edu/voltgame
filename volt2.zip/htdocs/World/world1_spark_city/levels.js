﻿export const World1Levels = {
  platforms: [
    { x: 0, y: 420, w: 2000, h: 80 },
    { x: 300, y: 330, w: 120, h: 20 }
  ]
};